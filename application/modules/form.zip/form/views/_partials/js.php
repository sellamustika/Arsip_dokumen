<script src="<?php echo base_url('assets/vendor/jquery/dist/jquery.min.js')?>"></script>
  <script src="<?php echo base_url('assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')?>"></script>
  <script src="<?php echo base_url('assets/vendor/js-cookie/js.cookie.js')?>"></script>
  <script src="<?php echo base_url('assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js')?>"></script>
  <script src="<?php echo base_url('assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')?>"></script>
  <!-- Optional JS -->
  <script src="<?php echo base_url('assets/vendor/chart.js/dist/Chart.min.js')?>"></script>
  <script src="<?php echo base_url('assets/vendor/chart.js/dist/Chart.extension.js')?>"></script>
  <!-- Argon JS -->
  <script src="<?php echo base_url('assets/js/argon.js?v=1.1.0')?>"></script>
  <!-- Demo JS - remove this in your project -->
  <script src="<?php echo base_url('assets/js/demo.min.js')?>"></script>